public class missingNumberArray
{

    public static void main(String[] args) {
        int ar[]={1,2,3,5};

        int firstValue=ar.length+1;

        int expctdSum=firstValue*(firstValue+1)/2;

        int actualSum=0;

        for(int a:ar)
        {
            actualSum+=a;
        }

        int missingNumber=expctdSum-actualSum;

        System.out.println(missingNumber);
    }

}
