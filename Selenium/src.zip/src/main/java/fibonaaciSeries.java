public class fibonaaciSeries {

    public static void main(String[] args) {

        //0,1,1,2,3,5,8
        int a=0; int b=1;

       int next=a+b;

       int i=3;
        System.out.print(a+" "+b);

        while(i<=10)
        {
            System.out.print(" "+next);
            a=b;       //1,1
            b=next;    //1,
            next=a+b;
            i++;
        }
    }
}
