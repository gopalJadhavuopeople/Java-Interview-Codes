import java.util.HashSet;

public class multipleMissingNoInArray
{

    public static void main(String[] args) {
        int ar[]={1,2,4,6,7,9};
        int lastDigit=9;

        HashSet<Integer> set=new HashSet<>();

        for(int a:ar)
        {
            set.add(a);
        }

        for(int i=1; i<lastDigit; i++)
        {
            if(!set.contains(i))
            {
                System.out.println("missing number is : "+i);
            }
        }
    }
}
