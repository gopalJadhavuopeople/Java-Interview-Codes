public class minMaxFromArray
{

    public static void main(String[] args) {
        int ar[]={0,100,2,3,6,3,7};

        int min=ar[0];
        int max=ar[0];

        for(int i=0; i<ar.length; i++)
        {
            if(ar[i]>max)
            {
                max=ar[i];
            }
            else if(ar[i]<min)
            {
                min=ar[i];
            }
        }

        System.out.println("min number is : "+min);
        System.out.println("max number is : "+max);
    }
}
