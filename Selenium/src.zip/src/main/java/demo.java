import java.util.HashMap;

public class demo {

    public static void main(String[] args) {
        String name="my my name";

        HashMap<Character,Integer> map=new HashMap<>();

        for(char ch: name.toCharArray())
        {
            if(map.containsKey(ch))
            {
                map.put(ch,map.get(ch)+1);
            }
            else
            {
                map.put(ch,1);
            }
        }

        for(char key: map.keySet())
        {
            System.out.println("for character '"+key+"' the count is "+map.get(key));
        }
    }
}
