package String;

public class lowerCaseToUpprCaseReqChar {

    public static void main(String[] args) {
        String name="kiran machhindra wadne";

        String ar[]=name.split(" ");

        String demo=" ";

        for(String a:ar)
        {

            if(Character.isLowerCase(a.charAt(0)))
            {
                demo=Character.toUpperCase(a.charAt(0))+a.substring(1)+" ";
            }
            System.out.print(demo);
        }


    }
}
