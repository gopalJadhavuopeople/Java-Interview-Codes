package array;

public class minMaxFromArray
{

    public static void main(String[] args) {
        int ar[]={0,100,3,3,6,3,7};

        int min=Integer.MAX_VALUE;
        int max=Integer.MIN_VALUE;

        for(int i=0; i<ar.length; i++)
        {
            if(ar[i]>max)
            {
                max=ar[i];
            }

            if(ar[i]<min)
            {
                min=ar[i];
            }
        }

        System.out.println("min number is : "+min);
        System.out.println("max number is : "+max);
    }
}
