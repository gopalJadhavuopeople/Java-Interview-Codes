package array;

import org.bson.io.BsonOutput;

import java.util.Arrays;
import java.util.Scanner;

public class nthLargestAndSmallestInArray {

    public static void main(String[] args) {

        int ar[] = {2, 5, 7, 8, 1, 10, 12, 8, 9};

        Scanner sc=new Scanner(System.in);
        int nthNumber=sc.nextInt();
        Arrays.sort(ar);

        System.out.println(Arrays.toString(ar));

        int nthSmallest=ar[nthNumber-1];
        System.out.println(nthSmallest);

        int nthlargeest=ar[ar.length-nthNumber];
        System.out.println(nthlargeest);

    }
}
